---
title: Der Wald  der Mll
date: 2022-08-01 10:00:00 -500
categories: [wald, umwelt, nachhaltig]
tags: [wald, umwelt, abfall, plastik, verschmutzung, nachhaltig]      # tags should always be lowercase
--- 

# whats up